# TruncateText


A component for truncating text content.

> For best results, avoid using TruncateText inside parent containers that are inline (`display: inline/inline-block`) or that default to inline display (span, link, etc.).

### Single line

```javascript
---
type: example
---

<div>
  <View
    as="div"
    padding="general.spaceXs none"
    maxWidth="480px"
    withVisualDebug
  >
    <Heading level="h1">
      <TruncateText>
        {lorem.paragraph()}
      </TruncateText>
    </Heading>
    <Text
      as="p"
      weight="bold"
      size="large"
      transform="uppercase"
      letterSpacing="expanded"
    >
      <TruncateText>
        {lorem.paragraph()}
      </TruncateText>
    </Text>
    <Text as="p">
      <TruncateText>
        {lorem.paragraph()}
      </TruncateText>
    </Text>

    <div>
      <TruncateText
        onUpdate={(truncated, text) => {
          console.log(truncated, text)
        }}
      >
        <Text>
          Regular sized text with <Link href="#">A Text Link </Link>and <Text weight="bold">some bold text.</Text>
        </Text>
      </TruncateText>
    </div>

  </View>
</div>
```

### Multiple lines

You can set the number of lines to display before truncation begins with the `maxLines` prop. Setting `maxLines` to `auto` will determine the number of lines that will fit.

```javascript
---
type: example
---
<div>
  <View
    as="div"
    padding="general.spaceMd none"
    maxWidth="480px"
    withVisualDebug
  >
    <Text as="p" size="large">
      <TruncateText
        maxLines={2}
        truncate="word"
        ellipsis=" (...)"
      >
        {lorem.paragraph()}
      </TruncateText>
      <Link href="#">Read More</Link>
    </Text>

    <Text as="p" lineHeight="double">
      <TruncateText
        maxLines={4}
        truncate="word"
        ellipsis=" (...)"
      >
        Esse aliqua minim veniam duis consectetur non sunt ea deserunt qui cillum laboris officia. Minim nulla commodo dolore reprehenderit commodo occaecat veniam ad consectetur mollit consectetur partur consectetur eiusmod dolor incididunt incididunt.
      </TruncateText>
      <Link href="#">Read More</Link>
    </Text>
  </View>
  <br />
  <View
    as="div"
    padding="general.spaceMd none"
    maxWidth="480px"
    withVisualDebug
  >
    <Text as="p">
      <TruncateText maxLines={4} ellipsis=" (...)">
        <span>Esse aliqua minim veniam duis consectetur non sunt ea deserunt qui cillum laboris officia. <Link href="#">http://instructure.github.io/instructure-ui/#ui-elements</Link> occaecat veniam ad consectetur mollit consectetur partur consectetur eiusmod dolor incididunt incididunt.</span>
      </TruncateText>
    </Text>

    <Text as="p">
      <TruncateText maxLines={4} ellipsis=" (...)">
        <span>Qui cillum laboris officia. <strong>supercalifragilisticexpialidocious</strong> occaecat veniam ad consectetur mollit consectetur partur consectetur eiusmod dolor incididunt incididunt. Esse aliqua minim veniam duis consectetur non sunt ea deserunt.</span>
      </TruncateText>
    </Text>
  </View>
  <br />
  <div style={{height: '78px', border: 'solid 1px red'}}>
    <Text>
      <TruncateText maxLines="auto" ellipsis=" (...)">
        Esse aliqua minim veniam duis consectetur non sunt ea deserunt qui cillum laboris officia. Minim nulla commodo dolore reprehenderit commodo occaecat veniam ad consectetur mollit consectetur partur consectetur eiusmod dolor incididunt incididunt.
      </TruncateText>
    </Text>
  </div>
</div>

```

### Truncate middle

You can set the position of the truncation using the `position` prop.

```javascript
---
type: example
---
<div>
  <View
    as="div"
    padding="general.spaceMd none"
    maxWidth="480px"
    withVisualDebug
  >
    <Text as="p">
      <TruncateText position="middle">
        <span>This line of text should be truncated from the middle of the string <strong>instead of the end.</strong></span>
      </TruncateText>
    </Text>
  </View>
  <br />
  <View
    as="div"
    padding="general.spaceMd none"
    maxWidth="480px"
    withVisualDebug
  >
    <Link href="#">
      <TruncateText
        position="middle"
        truncate="word"
        ellipsis=".../"
      >
        @instructure/ui-elements/somefakedir/tomakethislonger/lib/longer/TruncateText
      </TruncateText>
    </Link>
  </View>
</div>
```

### Using tooltips

It's best practice to make the complete text of a truncated element available via a [Tooltip](Tooltip).

```js
---
type: example
---
const Example = (props) => {
  const [isTruncated, setIsTruncated] = useState(false)

  const handleUpdate = (newIsTruncated) => {
    if (isTruncated !== newIsTruncated) {
      setIsTruncated(newIsTruncated)
    }
  }

  const renderLink = () => (
    <Link href="#">
      <TruncateText onUpdate={handleUpdate}>{props.message}</TruncateText>
    </Link>
  )

  return (
    <View as="div" padding="general.spaceXs none" maxWidth="230px" withVisualDebug>
      {isTruncated ? (
        <Tooltip
          renderTip={props.message}
          mountNode={() => document.getElementById('main')}
        >
          {renderLink()}
        </Tooltip>
      ) : (
        renderLink()
      )}
    </View>
  )
}
render(
  <Example message="A tooltip will display only when this text is truncated" />
)
```

### Guidelines

```js
---
type: embed
---
<Guidelines>
  <Figure recommendation="yes" title="Do">
    <Figure.Item>Use a <Link href="/#Tooltip">Tooltip</Link> for all truncated items</Figure.Item>
    <Figure.Item>Use when trying to restrict the number of lines that are visible</Figure.Item>
    <Figure.Item>Use end ellipsis if the unique identifier is at the beginning of the string</Figure.Item>
    <Figure.Item>Use middle ellipsis if the unique identifier is at the end of the string</Figure.Item>
  </Figure>
  <Figure recommendation="no" title="Don't">
    <Figure.Item>Use in <Link href="/#Button">Buttons</Link>, <Link href="/#Navigation">Nav Items</Link>, <Link href="/#TabList">TabLists</Link></Figure.Item>
  </Figure>
</Guidelines>
```


### Props

| Component | Prop | Type | Required | Default | Description |
|-----------|------|------|----------|---------|-------------|
| TruncateText | children | `React.ReactNode` | Yes | - | The content to be truncated. |
| TruncateText | debounce | `number` | No | `0` | Debounce delay in milliseconds |
| TruncateText | onUpdate | `(isTruncated: boolean, truncatedText?: string) => void` | No | - | Callback when truncated text has changed |
| TruncateText | maxLines | `'auto' \| number` | No | `1` | Number of lines to allow before truncating. `auto` will fit to parent. Default is 1. |
| TruncateText | position | `'end' \| 'middle'` | No | `'end'` | Where to place the ellipsis within the string. Default is 'end' |
| TruncateText | shouldTruncateWhenInvisible | `boolean` | No | - | Force truncation of invisible elements (hack; will be removed in favor of a better fix) |
| TruncateText | truncate | `'character' \| 'word'` | No | `'character'` | Add ellipsis after words or after any character. Default is 'character' |
| TruncateText | ellipsis | `string` | No | `'\u2026'` | A string to use as the ellipsis |
| TruncateText | ignore | `string[]` | No | `[' ', '.', ',']` | Characters to ignore at truncated end of string. Default is ' ', '.', ',' |

### Usage

Install the package:

```shell
npm install @instructure/ui-truncate-text
```

Import the component:

```javascript
/*** ES Modules (with tree shaking) ***/
import { TruncateText } from '@instructure/ui-truncate-text/v11_7'
```

