# Flex

@module Flex
The Flex component makes it simple for developers to create multi-column
layouts with flexbox.

### Layout direction

**Note:** Use the `withVisualDebug` property to see the borders of Flex/Flex.Item while developing!

Flex defaults to a `direction` of `row`, creating a horizontal layout. Change `direction` to
`column` to stack your Flex.Items.

> **Unless your layout has a specific/finite height, you probably don't need `direction="column"`.** To create a layout of stacked elements, it is simpler to use multiple [View](View) components with `display="block"`.

```js
---
type: example
---
<div>
  <Flex withVisualDebug margin="none none general.space2xl">
    <Flex.Item><Text>One</Text></Flex.Item>
    <Flex.Item><Text>Two</Text></Flex.Item>
    <Flex.Item><Text>Three</Text></Flex.Item>
    <Flex.Item><Text>Four</Text></Flex.Item>
  </Flex>
  <Flex withVisualDebug direction="column" margin="none none general.space2xl">
    <Flex.Item><Text>One</Text></Flex.Item>
    <Flex.Item><Text>Two</Text></Flex.Item>
    <Flex.Item><Text>Three</Text></Flex.Item>
    <Flex.Item><Text>Four</Text></Flex.Item>
  </Flex>
  <Flex withVisualDebug direction="row-reverse" margin="none none general.space2xl">
    <Flex.Item><Text>One</Text></Flex.Item>
    <Flex.Item><Text>Two</Text></Flex.Item>
    <Flex.Item><Text>Three</Text></Flex.Item>
    <Flex.Item><Text>Four</Text></Flex.Item>
  </Flex>
  <Flex withVisualDebug direction="column-reverse">
    <Flex.Item><Text>One</Text></Flex.Item>
    <Flex.Item><Text>Two</Text></Flex.Item>
    <Flex.Item><Text>Three</Text></Flex.Item>
    <Flex.Item><Text>Four</Text></Flex.Item>
  </Flex>
</div>
```

### Gap between Flex.Items

Flex items will have no gap by default. You can set the gap between Flex.Items by using the `gap` property.

```js
---
type: example
---
<div>
  <Flex withVisualDebug margin="none none general.space2xl" gap="general.spaceMd">
    <Flex.Item><Text>One</Text></Flex.Item>
    <Flex.Item><Text>Two</Text></Flex.Item>
    <Flex.Item><Text>Three</Text></Flex.Item>
    <Flex.Item><Text>Four</Text></Flex.Item>
  </Flex>
  <Flex withVisualDebug direction="column" margin="none none general.space2xl" gap="general.spaceXl">
    <Flex.Item><Text>One</Text></Flex.Item>
    <Flex.Item><Text>Two</Text></Flex.Item>
    <Flex.Item><Text>Three</Text></Flex.Item>
    <Flex.Item><Text>Four</Text></Flex.Item>
  </Flex>
  <Flex withVisualDebug direction="row-reverse" margin="none none general.space2xl" gap="general.spaceXl">
    <Flex.Item><Text>One</Text></Flex.Item>
    <Flex.Item><Text>Two</Text></Flex.Item>
    <Flex.Item><Text>Three</Text></Flex.Item>
    <Flex.Item><Text>Four</Text></Flex.Item>
  </Flex>
  <Flex withVisualDebug direction="column-reverse" gap="general.spaceMd">
    <Flex.Item><Text>One</Text></Flex.Item>
    <Flex.Item><Text>Two</Text></Flex.Item>
    <Flex.Item><Text>Three</Text></Flex.Item>
    <Flex.Item><Text>Four</Text></Flex.Item>
  </Flex>
</div>
```

You can also set the gap between rows and columns by using the `gap` property. Make sure that the `wrap` property is set to `wrap` or `wrap-reverse`.

```js
---
type: example
---
<div>
  <Flex withVisualDebug margin="none none general.space2xl" gap="general.spaceMd" wrap="wrap">
    <Flex.Item size='25rem'><Text>One</Text></Flex.Item>
    <Flex.Item size='25rem'><Text>Two</Text></Flex.Item>
    <Flex.Item size='25rem'><Text>Three</Text></Flex.Item>
    <Flex.Item size='25rem'><Text>Four</Text></Flex.Item>
  </Flex>
  <Flex withVisualDebug margin="none none general.space2xl" gap="general.spaceMd general.space2xl" wrap="wrap">
    <Flex.Item size='25rem'><Text>One</Text></Flex.Item>
    <Flex.Item size='25rem'><Text>Two</Text></Flex.Item>
    <Flex.Item size='25rem'><Text>Three</Text></Flex.Item>
    <Flex.Item size='25rem'><Text>Four</Text></Flex.Item>
  </Flex>
  <Flex withVisualDebug margin="none none general.space2xl" gap="general.spaceMd" wrap="wrap-reverse">
    <Flex.Item size='25rem'><Text>One</Text></Flex.Item>
    <Flex.Item size='25rem'><Text>Two</Text></Flex.Item>
    <Flex.Item size='25rem'><Text>Three</Text></Flex.Item>
    <Flex.Item size='25rem'><Text>Four</Text></Flex.Item>
  </Flex>
  <Flex withVisualDebug margin="none none general.space2xl" gap="general.spaceMd general.space2xl" wrap="wrap-reverse">
    <Flex.Item size='25rem'><Text>One</Text></Flex.Item>
    <Flex.Item size='25rem'><Text>Two</Text></Flex.Item>
    <Flex.Item size='25rem'><Text>Three</Text></Flex.Item>
    <Flex.Item size='25rem'><Text>Four</Text></Flex.Item>
  </Flex>
</div>
```

### Sizing Flex.Items

By default, Flex.Items **expand to fit their contents**, even if that means overflowing
their container.

```js
---
type: example
---
<Flex withVisualDebug>
  <Flex.Item padding="general.spaceSm">
    <Text>Villum dolore eu fugiat nulla pariatur.</Text>
  </Flex.Item>
  <Flex.Item padding="general.spaceSm">
    <Text>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</Text>
  </Flex.Item>
  <Flex.Item padding="general.spaceSm">
    <Text>Duis aute irure.</Text>
  </Flex.Item>
  <Flex.Item padding="general.spaceSm">
    <Text>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</Text>
  </Flex.Item>
</Flex>
```

Adding the `shouldShrink` property forces the Flex.Item to shrink as needed to fit inside its
container.

```js
---
type: example
---
<Flex withVisualDebug>
  <Flex.Item padding="general.spaceSm" shouldShrink>
    <Text>Villum dolore eu fugiat nulla pariatur.</Text>
  </Flex.Item>
  <Flex.Item padding="general.spaceSm" shouldShrink>
    <Text>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</Text>
  </Flex.Item>
  <Flex.Item padding="general.spaceSm" shouldShrink>
    <Text>Duis aute irure.</Text>
  </Flex.Item>
  <Flex.Item padding="general.spaceSm" shouldShrink>
    <Text>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</Text>
  </Flex.Item>
</Flex>
```

The `shouldGrow` property forces the Flex.Item to expand to fill in any available space.

```js
---
type: example
---
<Flex withVisualDebug>
  <Flex.Item padding="general.spaceSm" shouldShrink shouldGrow>
    <Text>I am growing and shrinking!</Text>
  </Flex.Item>
  <Flex.Item>
    <Text>I am not shrinking or growing.</Text>
  </Flex.Item>
</Flex>
```

The `size` property sets the base size (accepts px, em, rem) for the Flex.Item. If the
`direction` property is `row`, this is the item's **width**. If `direction` is `column`,
then it is the item's **height**. Flex.Items can grow beyond their `size`, but cannot
shrink to less than their `size`.

```js
---
type: example
---
<Flex withVisualDebug>
  <Flex.Item padding="general.spaceSm" size="200px">
    <Text>I am always 200px.</Text>
  </Flex.Item>
  <Flex.Item padding="general.spaceSm" shouldShrink shouldGrow size="200px">
    <Text>I can grow, and shrink down to 200px.</Text>
  </Flex.Item>
  <Flex.Item padding="general.spaceSm" size="25%">
    <Text>I am always 25%.</Text>
  </Flex.Item>
</Flex>
```

### Aligning Flex.Items

By default, Flex aligns its Flex.Items along the `center` of the axis. Use the `alignItems`
property to change this behavior.

`alignItems` can be overridden on individual Flex.Items through Flex.Item's `align` property.

```js
---
type: example
---
<Flex alignItems="end" withVisualDebug>
  <Flex.Item>
    <Avatar name="Sarah Robinson" size="large" src={avatarSquare} />
  </Flex.Item>
  <Flex.Item shouldGrow shouldShrink>
    <Text>I should be aligned to the bottom of the Avatar.</Text>
  </Flex.Item>
  <Flex.Item>
    <Text>Me, too.</Text>
  </Flex.Item>
  <Flex.Item align="start">
    <Text>I am aligning myself to the top.</Text>
  </Flex.Item>
</Flex>
```

### Justifying Flex.Items

Use the `justifyItems` property to change the justification of Flex.Items.

```js
---
type: example
---
<div>
  <Flex justifyItems="center" margin="0 0 general.space2xl" withVisualDebug>
    <Flex.Item>
      <Avatar name="Sarah Robinson" size="large" src={avatarSquare} />
    </Flex.Item>
    <Flex.Item>
      <Text>We are all centered!</Text>
    </Flex.Item>
    <Flex.Item>
      <Text>Yeah!</Text>
    </Flex.Item>
  </Flex>

  <Flex justifyItems="space-between" withVisualDebug margin="0 0 general.space2xl">
    <Flex.Item>
      <Avatar name="Sarah Robinson" size="large" src={avatarSquare} />
    </Flex.Item>
    <Flex.Item>
      <Text>Ah, a little more space.</Text>
    </Flex.Item>
    <Flex.Item>
      <Text>Totally.</Text>
    </Flex.Item>
  </Flex>

  <Flex justifyItems="end" withVisualDebug>
    <Flex.Item>
      <Avatar name="Sarah Robinson" size="large" src={avatarSquare} />
    </Flex.Item>
    <Flex.Item>
      <Text>Smooshed again.</Text>
    </Flex.Item>
    <Flex.Item>
      <Text>Ugh.</Text>
    </Flex.Item>
  </Flex>
</div>
```

### Handling overflow

When `direction` is set to `column`, Flex.Items' `overflowY` property is automagically set
to `auto` to account for content overflow with a vertical scrollbar. Add padding, so focus rings are not cut off.

> To override this default, simply set `overflowY` on the Flex.Item to either `visible` or `hidden`.

```js
---
type: example
---
  <Flex
    withVisualDebug
    direction="column"
  >
    <Flex.Item padding="general.spaceMd">
      <Heading>Pandas are cute, right?</Heading>
    </Flex.Item>
    <Flex.Item>
      <TextInput name="name" renderLabel="If you dont add padding, the focus ring will be cut off!" />
    </Flex.Item>
    <Flex.Item size="150px" padding="general.spaceMd">
      <Img src={avatarSquare} />
    </Flex.Item>
  </Flex>
```

### A few common layouts

#### Heading and button combination

```js
---
type: example
---
<Flex>
  <Flex.Item shouldGrow shouldShrink padding="none general.spaceXl none none">
    <Heading>Lorem ipsum dolor sit amet consectetur dolor sit</Heading>
  </Flex.Item>
  <Flex.Item>
    <Button margin="none general.spaceSm none none">
      Cancel
    </Button>
    <Button color="success" renderIcon={UserInstUIIcon}>
      Add user
    </Button>
  </Flex.Item>
</Flex>
```

#### Centered content (note the nested Flex components and use of the `wrap` property)

```js
---
type: example
---
<Flex height="32rem" justifyItems="center" padding="general.space2xl" withVisualDebug>
  <Flex.Item shouldShrink shouldGrow textAlign="center">

    <Heading level="h1" margin="0 0 general.spaceXl">An amazing thing!</Heading>

    <Flex withVisualDebug wrap="wrap" justifyItems="space-around" margin="0 0 general.spaceXl">
      <Flex.Item padding="general.spaceMd">
        <HeartInstUIIcon size="md" title="Icon Example" color="primary" />
        <Text weight="bold" size="large" as="div">We love you!</Text>
      </Flex.Item>
      <Flex.Item padding="general.spaceMd">
        <HeartInstUIIcon size="md" title="Icon Example" color="primary" />
        <Text weight="bold" size="large" as="div">We love you!</Text>
      </Flex.Item>
      <Flex.Item padding="general.spaceMd">
        <HeartInstUIIcon size="md" title="Icon Example" color="primary" />
        <Text weight="bold" size="large" as="div">We love you!</Text>
      </Flex.Item>
    </Flex>

    <div>
      <Button color="primary" size="large">Sign up now!</Button>
    </div>

  </Flex.Item>
</Flex>
```

#### Quick and dirty mobile app layout

```js
---
type: example
---

<Flex height="400px" width="300px" as="div" direction="column" withVisualDebug>

  <Flex.Item padding="general.spaceMd" as="header" textAlign="center">
    <Heading level="h3">App</Heading>
  </Flex.Item>

  <Flex.Item shouldGrow shouldShrink padding="general.spaceMd" as="main">
    <Text>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</Text>
  </Flex.Item>

  <Flex.Item padding="general.spaceMd" as="footer">

    <Flex withVisualDebug justifyItems="space-between">
      <Flex.Item>
        <IconButton
          renderIcon={MailInstUIIcon}
          withBackground={false}
          withBorder={false}
          screenReaderLabel="Some app function"
        />
      </Flex.Item>
      <Flex.Item>
        <IconButton
          renderIcon={PrinterInstUIIcon}
          withBackground={false}
          withBorder={false}
          screenReaderLabel="Some app function"
        />
      </Flex.Item>
      <Flex.Item>
        <IconButton
          renderIcon={Calendar1InstUIIcon}
          withBackground={false}
          withBorder={false}
          screenReaderLabel="Some app function"
        />
      </Flex.Item>
      <Flex.Item>
        <IconButton
          renderIcon={SettingsInstUIIcon}
          withBackground={false}
          withBorder={false}
          screenReaderLabel="Some app function"
        />
      </Flex.Item>
    </Flex>

  </Flex.Item>
</Flex>
```


### Props

| Component | Prop | Type | Required | Default | Description |
|-----------|------|------|----------|---------|-------------|
| Flex | children | `Renderable` | No | - | It's recommended that you use `Flex.Item` for children, but you can also pass any markup or a function returning markup. Note that if you do not use `Flex.Item`, the `withVisualDebug` and `direction` props will not automatically be set on the children. |
| Flex | as | `AsElementType` | No | `'span'` | the element type to render as |
| Flex | elementRef | `(element: Element \| null) => void` | No | - | provides a reference to the underlying html root element |
| Flex | height | `string \| number` | No | - | Sets the height of the component's container (optional) |
| Flex | width | `string \| number` | No | - | Sets the width of the component's container (optional) |
| Flex | margin | `Spacing` | No | - | Valid values are `0`, `none`, `auto`, and Spacing token values, see https://instructure.design/layout-spacing. Apply these values via familiar CSS-like shorthand. For example, `margin="general.spaceMd auto"`. |
| Flex | gap | `Spacing` | No | `'none'` | Valid values are `0`, `none`, and Spacing token values, see https://instructure.design/layout-spacing. Apply these values via familiar CSS-like shorthand. For example, `gap="general.spaceMd general.spaceLg"`. |
| Flex | padding | `Spacing` | No | - | Valid values are `0`, `none`, and Spacing token values, see https://instructure.design/layout-spacing. Apply these values via familiar CSS-like shorthand. For example, `padding="general.spaceMd general.spaceLg"`. |
| Flex | display | `'flex' \| 'inline-flex'` | No | `'flex'` | Sets the CSS display rule for the component's container |
| Flex | textAlign | `'start' \| 'center' \| 'end'` | No | - | Designates the text alignment |
| Flex | direction | `'row' \| 'column' \| 'row-reverse' \| 'column-reverse'` | No | `'row'` | Sets the flex-direction to row (horizontal) or column (vertical) |
| Flex | alignItems | `'center' \| 'start' \| 'end' \| 'stretch'` | No | - | Aligns Flex.Items on the vertical axis (horizontal if direction is column) |
| Flex | justifyItems | `'center' \| 'start' \| 'end' \| 'space-around' \| 'space-between'` | No | `'start'` | Aligns Flex.Items on the horizontal axis (vertical if direction is column) |
| Flex | wrap | `'wrap' \| 'no-wrap' \| 'wrap-reverse'` | No | `'no-wrap'` | Determines if the Flex.Items should wrap when they exceed their container's width |
| Flex | withVisualDebug | `boolean` | No | `false` | Activate a dotted outline around the component to make building your layout easier |
| Flex.Item | children | `React.ReactNode` | No | - | The children to render inside the Item |
| Flex.Item | as | `AsElementType` | No | `'span'` | the element type to render as |
| Flex.Item | elementRef | `(element: Element \| null) => void` | No | - | provides a reference to the underlying html root element |
| Flex.Item | margin | `Spacing` | No | - | Valid values are `0`, `none`, `auto`, and Spacing token values, see https://instructure.design/layout-spacing. Apply these values via familiar CSS-like shorthand. For example, `margin="general.spaceMd auto"`. |
| Flex.Item | padding | `Spacing` | No | - | Valid values are `0`, `none`, and Spacing token values, see https://instructure.design/layout-spacing. Apply these values via familiar CSS-like shorthand. For example, `padding="general.spaceMd general.spaceLg"`. |
| Flex.Item | align | `'center' \| 'start' \| 'end' \| 'stretch'` | No | - | overrides the parent Flex's alignItems prop, if needed |
| Flex.Item | direction | `'row' \| 'column'` | No | - | Inherits from the parent Flex component |
| Flex.Item | textAlign | `'start' \| 'center' \| 'end'` | No | - | Designates the text alignment inside the Item |
| Flex.Item | overflowX | `'auto' \| 'hidden' \| 'visible'` | No | - | Handles horizontal overflow |
| Flex.Item | overflowY | `'auto' \| 'hidden' \| 'visible'` | No | - | Handles vertical overflow |
| Flex.Item | shouldGrow | `boolean` | No | `false` | Should the FlexItem grow to fill any available space? |
| Flex.Item | shouldShrink | `boolean` | No | `false` | Should the FlexItem shrink (stopping at its `size`)? |
| Flex.Item | size | `string` | No | - | Sets the base size of the FlexItem (width if direction is `row`; height if direction is `column`) |
| Flex.Item | withVisualDebug | `boolean` | No | - | Places dashed lines around the component's borders to help debug your layout |
| Flex.Item | order | `number` | No | - | Specifies the order of the `Flex.Item` inside the `Flex` component. Utilizes the order flex CSS property. |

### Usage

Install the package:

```shell
npm install @instructure/ui-flex
```

Import the component:

```javascript
/*** ES Modules (with tree shaking) ***/
import { Flex } from '@instructure/ui-flex/v11_7'
```

